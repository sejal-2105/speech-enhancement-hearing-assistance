# DSP-Based Speech Enhancement System

A MATLAB GUI project that reduces background noise in speech using short-time, frequency-domain Digital Signal Processing (DSP). The interface lets users upload audio, tune enhancement parameters, listen to the original and enhanced signals, and inspect analysis plots.

## Application preview

![Figure 1: Main application interface — Home tab](assets/application_screenshot_1.png)

*Figure 1. Main application interface. The left panel provides audio upload/playback, noise-estimation duration, noise suppression, speech preservation, enhancement, and save controls. The Home tab compares the original noisy speech, enhanced speech, and the approximate component removed by DSP.*

![Figure 2: Analysis and DSP Demonstration tabs](assets/application_screenshot_2.png)

*Figure 2. Analysis and DSP Demonstration views. The upper section compares the original/enhanced frequency spectra and spectrograms. The lower section shows the estimated background-noise profile, suppression mask, one-frame spectrum before/after processing, and the speech/noise frame gate.*

> These screenshots are static examples supplied with the project. The plotted values depend on the input audio and selected parameters.

## What the graphs mean

| Graph | What it represents | X-axis | Y-axis / colour |
|---|---|---|---|
| **Original Noisy Speech** | Input waveform before processing. | Time (seconds) | Audio amplitude |
| **Enhanced Speech** | Reconstructed output after noise reduction. | Time (seconds) | Audio amplitude |
| **Approximate Component Removed by DSP** | Difference between original and enhanced signals. It may contain some speech detail as well as noise. | Time (seconds) | Difference/removed-signal amplitude |
| **Original FFT: Noise + Speech** | Frequency content of the input before enhancement. | Frequency (Hz) | Magnitude level (dB) |
| **Enhanced FFT: Reduced Noise** | Frequency content after enhancement; lower levels can indicate suppressed noise. | Frequency (Hz) | Magnitude level (dB) |
| **Original Spectrogram** | How the input signal's energy changes over time and frequency. | Time (seconds) | Frequency (Hz); colour represents magnitude/power (dB) |
| **Enhanced Spectrogram** | Time-frequency energy after processing, for comparison with the original spectrogram. | Time (seconds) | Frequency (Hz); colour represents magnitude/power (dB) |
| **Estimated Background Noise** | Estimated noise profile used by the algorithm. | Frequency (Hz) | Relative estimated noise level/power, as labelled |
| **Suppression Mask** | Frequency-dependent gain. Values near 1 preserve a frequency bin more; values near 0 suppress it more. | Frequency (Hz) | Gain/mask value (typically 0–1) |
| **One Speech Frame: Before / After** | Spectrum of one short speech frame before and after suppression. | Frequency (Hz) | Spectral magnitude (dB) |
| **Speech / Noise Frame Gate** | Frame energy and the gate decision across the recording. | Time (seconds) | Relative frame energy and gate/decision level (see legend) |
| **Original vs Enhanced Speech** | Comparison of input and output waveforms. | Time (seconds) | Audio amplitude |
| **Noise / Signal Component Removed** | Estimated difference signal removed during processing. | Time (seconds) | Difference/removed-signal amplitude |

## Comparing original and enhanced audio

1. Upload a noisy audio file.
2. Select **Play Original** to listen to the input.
3. Run **Enhance Speech**, then select **Play Enhanced** to listen to the output. Compare the same speech passage at a similar playback volume.
4. On the Home tab, check that the main speech events remain visible in the enhanced waveform. A smaller waveform alone does not prove better quality—listen as well.
5. Compare the **Original FFT** and **Enhanced FFT** to see which frequency regions have been attenuated. Compare the spectrograms to see how energy changes over time and frequency.
6. Use the removed-component plot as a diagnostic aid. It is not guaranteed to contain only noise; aggressive suppression can remove speech detail too.

## Main processing parameters

The current MATLAB implementation uses a 16 kHz processing sample rate, 512-sample frames, a 256-sample hop (50% overlap), a 0.60 s noise-estimation duration, 100% suppression setting, and 82% speech-preservation setting by default. The GUI controls may allow the user to adjust some parameters. See the project explanation document for the full parameter table and algorithm equations.

## Repository files

- `SpeechEnhancementSystem_Revised_v3(1).m` — MATLAB application source.
- `README.md` — project overview and graph guide.
- `assets/application_screenshot_1.png` — Home tab screenshot.
- `assets/application_screenshot_2.png` — Analysis and DSP Demonstration screenshot.
- `DSP_Speech_Enhancement_Project_Explanation_Updated.docx` — detailed project and graph explanation (if included in the repository).

## Running the application

1. Open the `.m` file in MATLAB.
2. Run the script/function as required by the file.
3. Upload a speech recording using the application controls.
4. Adjust noise-estimation and suppression parameters if needed, run enhancement, then inspect the plots and listen to both versions.

